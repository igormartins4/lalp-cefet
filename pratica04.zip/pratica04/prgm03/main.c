#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    int cod, quant;
    float total;

    setlocale(LC_ALL, "Portuguese");
    printf("\nDigite o c�digo do item pedido\n");
    scanf("%d", &cod);
    printf("\nDigite a quantidade:\n");
    scanf("%d", &quant);

    switch (cod) {

        case 100:
            total = quant * 1.20;
            printf("\nValor � ser pago: %.2f\n", total);
            break;

        case 101:
            total = quant * 1.30;
            printf("\nValor � ser pago: %.2f\n", total);
            break;

        case 102:
            total = quant * 1.50;
            printf("\nValor � ser pago: %.2f\n", total);
            break;

        case 103:
            total = quant * 1.20;
            printf("\nValor � ser pago: %.2f\n", total);
            break;

        case 104:
            total = quant * 1.30;
            printf("\nValor � ser pago: %.2f\n", total);
            break;

        case 105:
            total = quant * 1.00;
            printf("\nValor � ser pago: %.2f\n", total);
            break;

        default:
            printf("\nOp��o Inv�lida!\n\n");

    }
    return 0;
}
